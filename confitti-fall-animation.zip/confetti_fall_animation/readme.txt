=== Confitte Fall Animation ===
Contributors: Muhammad Shakeel
Tags: admin, plugin, new year, confitte fireworks, fireworks, christmas,celebration, toy, toys, fun, funny, fall animation, happy 
Requires at least: 3.0.1
Tested up to: 6.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Confitti fall animation Fireworks Celebration Plugin for your blog or website.

==============================================================================

Confetti fall animation License

Copyright (c) 2022 https://shakeel.yelleowpage.pk

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

