<?php

/**
 * @package confetti_fall_animation
 * @version 1.0.0
 **/

/*
Plugin Name: Confetti Fall Animation
Plugin URI: https://shakeel.yellowpage.pk
Description: Use the shortcode [confetti-fall-animation delay="1" time="25"] on any (individual) post or page to start a falling confetti animation.
Author: Muhammad Shakeel
Author URI: https://shakeel.yellowpage.pk/
Version: 1.0.0
License: GPLv2 or later
Text Domain: confetti_fall_animation
 */

defined('ABSPATH') or die('Hey, You can\'t access this directly.');

/* --- */

if (!function_exists("add_action")) {
    exit;
}

/* --- */

define("CFA_dir_url", plugin_dir_url(__FILE__));

/* --- */

$CFA_can_loaded = 0;

function CFA_templete_redirect()
{
    global $CFA_can_loaded;
    if ((is_page() or is_single()) and (strpos(get_post(get_the_ID())->post_content, "[confetti-fall-animation") !== false)) {
        $CFA_can_loaded = 1;
    }
}

add_action("template_redirect", "CFA_templete_redirect");

/* --- */

function CFA_enqueue_scripts()
{
    global $CFA_can_loaded;
    if ($CFA_can_loaded === 1) {
        wp_enqueue_script("jquery");
        wp_enqueue_script("confetti-js",CFA_dir_url . "assets/js/confetti.min.js");
        wp_enqueue_script("confetti-fall-animation",CFA_dir_url . "assets/js/confetti-fall-animation.js",array("jquery", "confetti-js"));
    }
}

add_action("wp_enqueue_scripts", "CFA_enqueue_scripts");

/* --- */

function CFA_html_view_page($props)
{
    global $CFA_can_loaded;
    if ($CFA_can_loaded === 1) {
        $props = shortcode_atts(
            array(
                "delay"    => "",
                "time" => "",
            ), $props
        );
        $delay    = $props["delay"];
        $time = $props["time"];
        return "<div class=\"confetti-fall-animation\" data-delay=\"" . $delay . "\" data-time=\"" . $time . "\"></div>";
    } else {
        return "";
    }
}

add_shortcode("confetti-fall-animation", "CFA_html_view_page");

/* --- */
